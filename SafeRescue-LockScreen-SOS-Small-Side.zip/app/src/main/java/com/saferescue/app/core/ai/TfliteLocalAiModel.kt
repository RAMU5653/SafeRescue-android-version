package com.saferescue.app.core.ai

import android.content.res.AssetFileDescriptor
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import org.tensorflow.lite.Interpreter

/**
 * TensorFlow Lite model adapter for a bundled, on-device model.
 * The model is loaded only from APK assets; no network/model download is used.
 */
class TfliteLocalAiModel(
    private val descriptor: AssetFileDescriptor,
    override val modelId: String,
    override val modelVersion: String
) : LocalAiModel {
    private val modelBuffer: ByteBuffer = FileInputStream(descriptor.fileDescriptor).use { input ->
        input.channel.position(descriptor.startOffset)
        val bytes = ByteArray(descriptor.declaredLength.toInt())
        var offset = 0
        while (offset < bytes.size) {
            val read = input.read(bytes, offset, bytes.size - offset)
            if (read <= 0) break
            offset += read
        }
        require(offset == bytes.size) { "Incomplete local model asset" }
        ByteBuffer.allocateDirect(bytes.size).order(ByteOrder.nativeOrder()).apply {
            put(bytes)
            rewind()
        }
    }

    private val interpreter = Interpreter(modelBuffer, Interpreter.Options().apply {
        setNumThreads(2)
    })

    override fun infer(input: FloatArray): FloatArray {
        val output = Array(1) { FloatArray(2) }
        interpreter.run(arrayOf(input), output)
        return output[0]
    }

    override fun close() {
        interpreter.close()
        descriptor.close()
    }
}
